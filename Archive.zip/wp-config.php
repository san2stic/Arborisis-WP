<?php
/**
 * Arborisis WordPress Configuration
 *
 * Uses environment variables for all sensitive data
 */

// ** Environment ** //
define('WP_ENV', getenv('WP_ENV') ?: 'development');
define('WP_DEBUG', WP_ENV !== 'production');
define('WP_DEBUG_LOG', WP_ENV !== 'production');
define('WP_DEBUG_DISPLAY', false);
define('SCRIPT_DEBUG', WP_ENV === 'development');

// ** Database ** //
define('DB_NAME', getenv('DB_NAME') ?: 'arborisis');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASSWORD', getenv('DB_PASSWORD') ?: '');
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', '');

// ** WordPress URLs ** //
define('WP_HOME', getenv('WP_HOME') ?: 'http://localhost');
define('WP_SITEURL', getenv('WP_SITEURL') ?: WP_HOME);

// ** Authentication Unique Keys and Salts ** //
define('AUTH_KEY',         getenv('AUTH_KEY') ?: 'put your unique phrase here');
define('SECURE_AUTH_KEY',  getenv('SECURE_AUTH_KEY') ?: 'put your unique phrase here');
define('LOGGED_IN_KEY',    getenv('LOGGED_IN_KEY') ?: 'put your unique phrase here');
define('NONCE_KEY',        getenv('NONCE_KEY') ?: 'put your unique phrase here');
define('AUTH_SALT',        getenv('AUTH_SALT') ?: 'put your unique phrase here');
define('SECURE_AUTH_SALT', getenv('SECURE_AUTH_SALT') ?: 'put your unique phrase here');
define('LOGGED_IN_SALT',   getenv('LOGGED_IN_SALT') ?: 'put your unique phrase here');
define('NONCE_SALT',       getenv('NONCE_SALT') ?: 'put your unique phrase here');

// ** Redis Cache ** //
define('WP_REDIS_HOST', getenv('REDIS_HOST') ?: 'localhost');
define('WP_REDIS_PORT', getenv('REDIS_PORT') ?: 6379);
define('WP_REDIS_PASSWORD', getenv('REDIS_PASSWORD') ?: '');
define('WP_REDIS_DATABASE', getenv('REDIS_DB') ?: 0);
define('WP_CACHE_KEY_SALT', getenv('WP_HOME') ?: 'arborisis');

// ** WP-Cron ** //
define('DISABLE_WP_CRON', getenv('DISABLE_WP_CRON') === 'true');

// ** Performance ** //
define('WP_MEMORY_LIMIT', '256M');
define('WP_MAX_MEMORY_LIMIT', '512M');

// ** Security ** //
define('DISALLOW_FILE_EDIT', true);
define('FORCE_SSL_ADMIN', WP_ENV === 'production');

// ** Database Table prefix ** //
$table_prefix = 'wp_';

// ** Absolute path to the WordPress directory ** //
if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}

// ** Sets up WordPress vars and included files ** //
require_once ABSPATH . 'wp-settings.php';
